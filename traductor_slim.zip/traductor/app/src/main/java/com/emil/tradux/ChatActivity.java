package com.emil.tradux;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class ChatActivity extends AppCompatActivity {


    private static final String API_KEY = "AIzaSyAWxQwB_IQ9EXImwOD2iKIDFynSyNNMD8A";

    private final OkHttpClient client = new OkHttpClient();

    private final List<ChatMessage> chat = new ArrayList<>();
    private ChatAdapter adapter;
    private EditText etMessage;
    private ImageButton btnSend;
    private ProgressBar pbLoading;  // loader central

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        // Referencias a vistas
        pbLoading = findViewById(R.id.pbLoading);
        RecyclerView rvChat = findViewById(R.id.rvChat);
        etMessage = findViewById(R.id.etMessage);
        btnSend = findViewById(R.id.btnSend);

        // Configuración del RecyclerView
        adapter = new ChatAdapter(chat);
        rvChat.setLayoutManager(new LinearLayoutManager(this));
        rvChat.setAdapter(adapter);

        // Envío de mensaje al hacer click
        btnSend.setOnClickListener(v -> {
            String text = etMessage.getText().toString().trim();
            if (text.isEmpty()) return;
            etMessage.setText("");
            addMessage(text, true);
            callGoogleGemini(text);
        });
    }

    private void addMessage(String text, boolean isUser) {
        runOnUiThread(() -> {
            chat.add(new ChatMessage(text, isUser));
            adapter.notifyItemInserted(chat.size() - 1);
        });
    }

    private void callGoogleGemini(String prompt) {
        // Mostrar loader
        runOnUiThread(() -> pbLoading.setVisibility(View.VISIBLE));

        String url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=" + API_KEY;

        JsonObject payload = new JsonObject();
        JsonArray contents = new JsonArray();
        JsonObject part = new JsonObject();
        JsonObject textPart = new JsonObject();
        textPart.addProperty("text", prompt);
        part.add("parts", new JsonArray());
        part.getAsJsonArray("parts").add(textPart);
        contents.add(part);
        payload.add("contents", contents);

        RequestBody body = RequestBody.create(
                payload.toString(),
                MediaType.get("application/json; charset=utf-8")
        );

        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                // Ocultar loader y mostrar error
                runOnUiThread(() -> pbLoading.setVisibility(View.GONE));
                addMessage("Error en la conexión: " + e.getMessage(), false);
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                // Ocultar loader
                runOnUiThread(() -> pbLoading.setVisibility(View.GONE));

                if (!response.isSuccessful()) {
                    String errorBody = response.body() != null ? response.body().string() : "Sin detalles";
                    addMessage("Error HTTP: " + response.code() + " " + errorBody, false);
                    return;
                }

                try {
                    String respBody = response.body().string();
                    JsonObject jsonObject = JsonParser.parseString(respBody).getAsJsonObject();

                    String reply = jsonObject
                            .getAsJsonArray("candidates")
                            .get(0).getAsJsonObject()
                            .getAsJsonObject("content")
                            .getAsJsonArray("parts")
                            .get(0).getAsJsonObject()
                            .get("text")
                            .getAsString();

                    addMessage(reply.trim(), false);

                } catch (Exception e) {
                    addMessage("Error al procesar la respuesta: " + e.getMessage(), false);
                }
            }
        });
    }
}
