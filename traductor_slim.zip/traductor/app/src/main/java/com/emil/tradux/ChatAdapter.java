package com.emil.tradux;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * Adaptador para el RecyclerView que muestra la lista de mensajes del chat.
 * Distingue entre mensajes enviados por el usuario y los recibidos del bot,
 * usando layouts diferentes para cada uno.
 */
public class ChatAdapter extends RecyclerView.Adapter<ChatAdapter.MessageHolder> { // CAMBIO 1

    private static final int VIEW_TYPE_BOT = 0;
    private static final int VIEW_TYPE_USER = 1;

    // CAMBIO 2: Hacer la lista 'final' es una buena práctica si no la vas a reasignar.
    private final List<ChatMessage> items;

    public ChatAdapter(List<ChatMessage> items) {
        this.items = items;
    }

    @Override
    public int getItemViewType(int position) {
        // La lógica original es perfecta.
        return items.get(position).isUser() ? VIEW_TYPE_USER : VIEW_TYPE_BOT;
    }

    @NonNull
    @Override
    public MessageHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) { // CAMBIO 3
        int layoutRes;
        if (viewType == VIEW_TYPE_USER) {
            layoutRes = R.layout.item_user_msg;
        } else {
            layoutRes = R.layout.item_bot_msg;
        }

        View view = LayoutInflater.from(parent.getContext())
                .inflate(layoutRes, parent, false);

        return new MessageHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MessageHolder holder, int position) { // CAMBIO 3 y 4
        ChatMessage message = items.get(position);
        holder.bind(message); // La lógica de binding se mueve al ViewHolder
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    /**
     * ViewHolder que contiene la vista de un único mensaje (sea de usuario o de bot).
     */
    static class MessageHolder extends RecyclerView.ViewHolder {
        TextView tvMsg;

        MessageHolder(@NonNull View itemView) {
            super(itemView);
            // La búsqueda de la vista es la misma, ya que ambos layouts usan el mismo ID.
            tvMsg = itemView.findViewById(R.id.tvMsg);
        }

        // CAMBIO 5: Método para encapsular la lógica de asignación de datos.
        void bind(ChatMessage message) {
            tvMsg.setText(message.getText());
        }
    }
}