package com.emil.tradux;

public class Translation {
    public String sourceText;
    public String translatedText;

    // Constructor vacío requerido por Firestore
    public Translation() {}

    public Translation(String sourceText, String translatedText) {
        this.sourceText = sourceText;
        this.translatedText = translatedText;
    }
}
