package com.emil.tradux;

import java.util.Objects;

public class ChatMessage {
    private final String text;
    private final boolean isUser;

    public ChatMessage(String text, boolean isUser) {
        this.text = text;
        this.isUser = isUser;
    }

    public String getText() {
        return text;
    }

    public boolean isUser() {
        return isUser;
    }

    // --- MEJORAS AÑADIDAS ---

    /**
     * Compara este objeto con otro para ver si son "iguales".
     * Dos mensajes son iguales si tienen el mismo texto y el mismo emisor.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ChatMessage that = (ChatMessage) o;
        return isUser == that.isUser && Objects.equals(text, that.text);
    }

    /**
     * Genera un número único (hash) basado en el contenido del objeto.
     * Esencial si usas colecciones como HashSet o HashMap.
     */
    @Override
    public int hashCode() {
        return Objects.hash(text, isUser);
    }

    /**
     * Devuelve una representación en texto del objeto, ¡muy útil para depurar!
     */
    @Override
    public String toString() {
        return "ChatMessage{" +
                "text='" + text + '\'' +
                ", isUser=" + isUser +
                '}';
    }
}