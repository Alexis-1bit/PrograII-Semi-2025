package com.emil.tradux;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import org.json.JSONObject;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private EditText inputText, outputText;
    private Spinner sourceLangSpinner, targetLangSpinner;
    private Button translateButton, copyButton;

    private final String[] languageNames = {
            "Español","Inglés","Francés","Alemán","Italiano",
            "Portugués","Ruso","Japonés","Árabe","Chino"
    };
    private final String[] languageCodes = {
            "es","en","fr","de","it",
            "pt","ru","ja","ar","zh"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Comprueba que haya usuario logueado
        mAuth = FirebaseAuth.getInstance();
        FirebaseUser user = mAuth.getCurrentUser();
        if (user == null) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        setContentView(R.layout.activity_main);

        // Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Referencias a vistas
        inputText         = findViewById(R.id.inputText);
        outputText        = findViewById(R.id.outputText);
        translateButton   = findViewById(R.id.translateButton);
        copyButton        = findViewById(R.id.copyButton);
        sourceLangSpinner = findViewById(R.id.sourceLangSpinner);
        targetLangSpinner = findViewById(R.id.targetLangSpinner);

        // Spinner de idiomas
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, languageNames);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sourceLangSpinner.setAdapter(adapter);
        targetLangSpinner.setAdapter(adapter);
        sourceLangSpinner.setSelection(0);
        targetLangSpinner.setSelection(1);

        // Botones
        translateButton.setOnClickListener(v -> translateText());
        copyButton.setOnClickListener(v -> {
            String t = outputText.getText().toString().trim();
            if (!t.isEmpty()) {
                ClipboardManager cb = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
                cb.setPrimaryClip(ClipData.newPlainText(
                        getString(R.string.clipboard_label), t
                ));
                Toast.makeText(this, R.string.toast_copied, Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, R.string.toast_nothing_to_copy, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void translateText() {
        String text = inputText.getText().toString().trim();
        if (text.isEmpty()) {
            outputText.setText(R.string.error_empty_input);
            return;
        }
        String from = languageCodes[sourceLangSpinner.getSelectedItemPosition()];
        String to   = languageCodes[targetLangSpinner.getSelectedItemPosition()];

        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                String q    = URLEncoder.encode(text, "UTF-8");
                String pair = from + "|" + to;
                String urlStr = "https://api.mymemory.translated.net/get"
                        + "?q=" + q
                        + "&langpair=" + URLEncoder.encode(pair, "UTF-8");

                URL url = new URL(urlStr);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");

                int code = conn.getResponseCode();
                if (code == 200) {
                    try (InputStream is = conn.getInputStream();
                         Scanner sc = new Scanner(is).useDelimiter("\\A")) {

                        String resp = sc.hasNext() ? sc.next() : "";
                        JSONObject root = new JSONObject(resp);
                        String tt = root
                                .getJSONObject("responseData")
                                .getString("translatedText");
                        runOnUiThread(() -> outputText.setText(tt));
                    }
                } else {
                    runOnUiThread(() -> outputText.setText(
                            getString(R.string.error_translate, code)
                    ));
                }
            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> outputText.setText(R.string.error_network));
            } finally {
                if (conn != null) conn.disconnect();
            }
        }).start();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_chat) {
            startActivity(new Intent(this, ChatActivity.class));
            return true;
        } else if (id == R.id.action_logout) {
            mAuth.signOut();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
